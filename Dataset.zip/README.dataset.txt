# People > 2023-09-16 10:31pm
https://universe.roboflow.com/people-counter-aa0us/people-xs3yy

Provided by a Roboflow user
License: CC BY 4.0

